import cv2
import os
import time

print("正在初始化摄像头,请稍后...")
cap = cv2.VideoCapture(0)
while True:
    name = input("初始化成功！\n请输入姓名拼音（输入后按下回车采集开始）：")
    print("采集即将开始（每隔0.2s拍摄一张，共计600张）")
    savedpath = 'D:/faceImages/' + name
    os.makedirs(savedpath)
    print("人脸信息子文件夹创建成功")
    print('调整姿势\n正常速度转动头部，保证脸部每个角度都有照片\n按下，y再打回车，弹窗出现即自动开始拍照')
    while True:
        hehe = input()
        if hehe == 'y':
            break
    flag = 1
    num = 1
    while(cap.isOpened()):
        ret_flag, Vshow = cap.read()
        cv2.imshow("Capture_Test", Vshow)
        savedname = '/'  + str(num) +  '.jpg'
        cv2.imwrite(savedpath + savedname, Vshow)
        print('%s.jpg successful'%(num))
        num += 1
        if num == 601:
            break
        k = cv2.waitKey(1) & 0xFF
        if k == ord('o'):
            break
        if k == ord('p'):
            print('暂停中，按c继续')
            while True:
                ret_flag, Vshow = cap.read()
                cv2.imshow("Capture_Test", Vshow)
                k = cv2.waitKey(1) & 0xFF
                if k == ord('c'):
                    break
        time.sleep(0.02)  # 延时0.2s,每隔0.2s拍摄一张

    print('拍照进程结束，继续按a后回车，退出按q后回车')
    k = input()
    if k == 'a':
        i = 0
    if k == 'q':
        break

cap.release()
cv2.destroyAllWindows()


